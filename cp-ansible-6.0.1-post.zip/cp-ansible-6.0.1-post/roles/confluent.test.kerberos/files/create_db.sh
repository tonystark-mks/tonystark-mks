#!/bin/bash
echo -e "$1\n$1" | kdb5_util create -s

